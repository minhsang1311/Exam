using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Exam.Views.Department
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
