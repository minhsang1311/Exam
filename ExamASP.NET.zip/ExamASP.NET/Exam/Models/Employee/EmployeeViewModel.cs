﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Exam.Models.Employee
{
    public class EmployeeViewModel
    {
        [Required(ErrorMessage = "Enter Name")]
        [Display(Name = "Name")]// hien thi ra ngoai view
        public string name { get; set; }

        [Required(ErrorMessage = "Enter Code")]
        [Display(Name = "Code")]
        public string code { get; set; }

        
        [Required(ErrorMessage = "Enter Rank")]
        [Display(Name = "Rank")]
        public string rank { get; set; }

        [Required(ErrorMessage = "Please Choose Department")]
        [Display(Name = "Department")]
        public int department_id { get; set; }
    }
}
