﻿using System.ComponentModel.DataAnnotations;

namespace Exam.Models.Employee
{
    public class EmployeeEditModel
    {
        [Required]
        public int id { get; set; }

        [Required(ErrorMessage = "Enter Name")]
        [Display(Name = "Name")]// hien thi ra ngoai view
        public string name { get; set; }

        [Required(ErrorMessage = "Enter Code")]
        [Display(Name = "Code")]
        public string code { get; set; }


        [Required(ErrorMessage = "Enter Rank")]
        [Display(Name = "Rank")]
        public string rank { get; set; }

        [Required(ErrorMessage = "Please Choose Department")]
        [Display(Name = "Department")]
        public int department_id { get; set; }
    }
}
