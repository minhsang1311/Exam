﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Exam.Models.Department
{
    public class DepartmentViewModel
    {
        [Required(ErrorMessage = "Enter Name")]
        [Display(Name = "Name")]// hien thi ra ngoai view
        public string name { get; set; }

        [Required(ErrorMessage = "Enter Code")]
        [Display(Name = "Code")]
        public string code { get; set; }

        [Column(TypeName = "text")]
        [Required(ErrorMessage = "Enter Loction")]
        [Display(Name = "Location")]
        public string location { get; set; }

        [Required(ErrorMessage = "Enter")]
        [Display(Name = "numberOfPersonals")]
        public int numberOfPersonals { get; set; }

        
    }
}
